# CH34x USB-UART converter driver

[![Component Registry](https://components.espressif.com/components/espressif/usb_host_ch34x_vcp/badge.svg)](https://components.espressif.com/components/espressif/usb_host_ch34x_vcp)

Limited implementation only. The vendor does not provide full specification.

* CH340 and CH341 supported
* [Datasheet](http://www.wch-ic.com/downloads/CH341DS1_PDF.html)
