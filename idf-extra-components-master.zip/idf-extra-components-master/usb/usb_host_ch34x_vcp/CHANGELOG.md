## 1.0.0
- Initial version

## 1.0.1
- Fix GCC-12 compile errors

## 2.0.0
- Update to [CDC-ACM driver](https://components.espressif.com/components/espressif/usb_host_cdc_acm) to v2
