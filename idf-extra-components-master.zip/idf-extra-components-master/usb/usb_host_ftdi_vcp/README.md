# FTDI UART-USB converters driver

[![Component Registry](https://components.espressif.com/components/espressif/usb_host_ftdi_vcp/badge.svg)](https://components.espressif.com/components/espressif/usb_host_ftdi_vcp)

Supported devices:
* FT231
* FT232
