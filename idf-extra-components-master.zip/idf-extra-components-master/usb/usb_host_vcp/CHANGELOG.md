## 1.0.0
- Initial version

## 1.0.0~1
- Claim compatibility with [CDC-ACM driver](https://components.espressif.com/components/espressif/usb_host_cdc_acm) v2
