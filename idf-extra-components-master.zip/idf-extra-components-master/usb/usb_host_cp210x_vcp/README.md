# Silicon Labs CP210x USB-UART converter driver

[![Component Registry](https://components.espressif.com/components/espressif/usb_host_cp210x_vcp/badge.svg)](https://components.espressif.com/components/espressif/usb_host_cp210x_vcp)

* [Datasheet](https://www.silabs.com/documents/public/data-sheets/CP2102-9.pdf)
* [Application note](https://www.silabs.com/documents/public/application-notes/an197.pdf)
