# PNG image encoding and decoding library

[![Component Registry](https://components.espressif.com/components/espressif/libpng/badge.svg)](https://components.espressif.com/components/espressif/libpng)

This is an IDF component for libpng library.

For usage instructions, please refer to the official documentation: http://www.libpng.org/pub/png/libpng.html
