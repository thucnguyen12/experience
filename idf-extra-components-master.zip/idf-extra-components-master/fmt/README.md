 # FMT
 
 [![Component Registry](https://components.espressif.com/components/espressif/fmt/badge.svg)](https://components.espressif.com/components/espressif/fmt)
 
**fmt** is an open-source formatting library providing a fast and safe
alternative to C stdio and C++ iostreams.

See the project [README](fmt/README.rst) for details.


