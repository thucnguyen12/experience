# Simple PCAP file writer

[![Component Registry](https://components.espressif.com/components/espressif/pcap/badge.svg)](https://components.espressif.com/components/espressif/pcap)

This component allows users to trace their captured packets in .pcap file format.

More details about PCAP format can be found [here](https://wiki.wireshark.org/Development/LibpcapFileFormat).
