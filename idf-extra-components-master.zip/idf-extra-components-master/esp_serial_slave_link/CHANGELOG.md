## 1.1.0

- Supported communicating with ESP32C6 SDIO Slave

## 1.0.1

- Fixed build failure issue on chip which doesn't support SDMMC host
- Remove dependency to `soc/host_reg.h`

## 1.0.0

- Inititial version
