# 1-Wire Bus Driver

[![Component Registry](https://components.espressif.com/components/espressif/onewire_bus/badge.svg)](https://components.espressif.com/components/espressif/onewire_bus)

This directory contains an implementation for 1-Wire bus by different peripherals. Currently only RMT is supported as the backend.
