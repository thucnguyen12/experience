## 1.0.0

- Initial driver version, with the RMT driver as backend controller
