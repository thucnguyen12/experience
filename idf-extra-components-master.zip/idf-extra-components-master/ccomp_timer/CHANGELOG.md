## 1.0.0

- Move the cache compensated timer from `esp-idf/tools/unit-test-app/components` to component registry.
