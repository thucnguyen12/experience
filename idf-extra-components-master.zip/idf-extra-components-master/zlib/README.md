# Zlib compression and decompression Library

[![Component Registry](https://components.espressif.com/components/espressif/zlib/badge.svg)](https://components.espressif.com/components/espressif/zlib)

This is an IDF component for zlib library.

For usage instructions, please refer to the official documentation: https://www.zlib.net/manual.html
