const char IQmathLibVersionString[] = "IQmathLib version 01_11_00_00";

const char *_IQmathLibVersionString(void)
{
    return IQmathLibVersionString;
}
