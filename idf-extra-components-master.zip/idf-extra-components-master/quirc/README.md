# Quirc QR code decoding library

[![Component Registry](https://components.espressif.com/components/espressif/quirc/badge.svg)](https://components.espressif.com/components/espressif/quirc)

This is an ESP-IDF component for [quirc](https://github.com/dlbeer/quirc), a QR code decoding library.

Please refer to https://github.com/dlbeer/quirc#library-use for the introduction to this library.

See also the `qrcode` component for generation of QR codes ([registry](https://components.espressif.com/components/espressif/qrcode), [source](../qrcode/README.md)).
